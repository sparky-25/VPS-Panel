# Ubuntu VPS Panel

A small Codespaces-friendly web panel with:

- Real shell sessions through `node-pty`
- Multiple terminal tabs
- File browser and text preview
- System info panel
- Optional token protection with `PANEL_TOKEN`

## GitHub Codespaces Setup

Create a GitHub repo named `VPS`, add these files, then open the repo in Codespaces.

Run:

```bash
npm install
PANEL_TOKEN=change-this npm start
```

Open the forwarded port `3000` from the Codespaces **Ports** tab.

For quick testing without a password:

```bash
npm install
npm start
```

## Useful Options

```bash
PANEL_TOKEN=change-this npm start
PANEL_ROOT=/workspaces/VPS npm start
PORT=8080 npm start
```

`PANEL_TOKEN` is strongly recommended if the forwarded port is shared with anyone.

## Docker

```bash
docker build -t ubuntu-vps-panel .
docker run --rm -p 3000:3000 -e PANEL_TOKEN=change-this ubuntu-vps-panel
```

## Important

This gives terminal access to the machine running the app. Keep the Codespaces port private unless you fully trust the person using it.
