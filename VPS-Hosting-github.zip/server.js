const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const pty = require("node-pty");
const path = require("path");
const fs = require("fs");
const fsp = require("fs/promises");
const os = require("os");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = Number(process.env.PORT || 3000);
const PANEL_TOKEN = process.env.PANEL_TOKEN || "";
const ROOT_DIR = path.resolve(
  process.env.PANEL_ROOT || process.env.GITHUB_WORKSPACE || process.cwd()
);
const MAX_PREVIEW_BYTES = Number(process.env.MAX_PREVIEW_BYTES || 512 * 1024);

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use("/api", (req, res, next) => {
  if (!PANEL_TOKEN || tokenFromRequest(req) === PANEL_TOKEN) {
    return next();
  }

  return res.status(401).json({ error: "Invalid panel token" });
});

app.get("/api/system", (req, res) => {
  const cpus = os.cpus();
  const user = safeUserInfo();

  res.json({
    hostname: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    arch: os.arch(),
    shell: preferredShell(),
    root: ROOT_DIR,
    user: user.username || "codespace",
    cpu: cpus[0] ? cpus[0].model : "Unknown CPU",
    cores: cpus.length,
    load: os.loadavg().map((value) => Number(value.toFixed(2))),
    memory: {
      total: bytesToHuman(os.totalmem()),
      free: bytesToHuman(os.freemem()),
    },
    uptime: secondsToHuman(os.uptime()),
  });
});

app.get("/api/files", async (req, res) => {
  try {
    const directory = resolveInsideRoot(req.query.path || "");
    const stat = await fsp.stat(directory);

    if (!stat.isDirectory()) {
      return res.status(400).json({ error: "Path is not a directory" });
    }

    const entries = await fsp.readdir(directory, { withFileTypes: true });
    const files = await Promise.all(
      entries.map(async (entry) => {
        const absolutePath = path.join(directory, entry.name);
        const itemStat = await safeLstat(absolutePath);
        const type = entry.isDirectory()
          ? "folder"
          : entry.isSymbolicLink()
            ? "link"
            : "file";

        return {
          name: entry.name,
          type,
          path: toPanelPath(absolutePath),
          size: itemStat ? itemStat.size : 0,
          modified: itemStat ? itemStat.mtime.toISOString() : null,
        };
      })
    );

    files.sort((a, b) => {
      if (a.type !== b.type) {
        return a.type === "folder" ? -1 : 1;
      }

      return a.name.localeCompare(b.name);
    });

    const currentPath = toPanelPath(directory);
    const parentPath = currentPath ? toPanelPath(path.dirname(directory)) : null;

    res.json({
      root: ROOT_DIR,
      path: currentPath,
      parent: parentPath,
      files,
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.get("/api/file", async (req, res) => {
  try {
    const filePath = resolveInsideRoot(req.query.path || "");
    const stat = await fsp.stat(filePath);

    if (!stat.isFile()) {
      return res.status(400).json({ error: "Path is not a file" });
    }

    if (stat.size > MAX_PREVIEW_BYTES) {
      return res.status(413).json({
        error: `File is bigger than ${bytesToHuman(MAX_PREVIEW_BYTES)}`,
      });
    }

    const buffer = await fsp.readFile(filePath);

    if (buffer.includes(0)) {
      return res.status(415).json({ error: "Binary file preview is blocked" });
    }

    res.json({
      name: path.basename(filePath),
      path: toPanelPath(filePath),
      size: stat.size,
      modified: stat.mtime.toISOString(),
      content: buffer.toString("utf8"),
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

io.use((socket, next) => {
  if (!PANEL_TOKEN || socket.handshake.auth.token === PANEL_TOKEN) {
    return next();
  }

  return next(new Error("Invalid panel token"));
});

io.on("connection", (socket) => {
  const cols = clampNumber(socket.handshake.query.cols, 40, 240, 120);
  const rows = clampNumber(socket.handshake.query.rows, 12, 80, 32);
  const shell = preferredShell();
  const args = shellArgs(shell);

  const terminal = pty.spawn(shell, args, {
    name: "xterm-256color",
    cols,
    rows,
    cwd: ROOT_DIR,
    env: {
      ...process.env,
      TERM: "xterm-256color",
      COLORTERM: "truecolor",
    },
  });

  socket.emit(
    "output",
    `\r\nConnected to ${os.hostname()} | ${ROOT_DIR}\r\n`
  );

  terminal.onData((data) => {
    socket.emit("output", data);
  });

  terminal.onExit(({ exitCode }) => {
    socket.emit("output", `\r\nShell exited with code ${exitCode}\r\n`);
    socket.emit("exit", { exitCode });
  });

  socket.on("input", (data) => {
    terminal.write(data);
  });

  socket.on("resize", ({ cols: nextCols, rows: nextRows }) => {
    try {
      terminal.resize(
        clampNumber(nextCols, 40, 240, 120),
        clampNumber(nextRows, 12, 80, 32)
      );
    } catch (error) {
      socket.emit("output", `\r\nResize failed: ${error.message}\r\n`);
    }
  });

  socket.on("disconnect", () => {
    try {
      terminal.kill();
    } catch (error) {
      // Terminal may already be gone.
    }
  });
});

server.listen(PORT, () => {
  console.log("");
  console.log("Ubuntu VPS Panel is running");
  console.log(`Local: http://localhost:${PORT}`);
  console.log(`Root:  ${ROOT_DIR}`);
  if (PANEL_TOKEN) {
    console.log("Auth:  PANEL_TOKEN is enabled");
  } else {
    console.log("Auth:  no PANEL_TOKEN set");
  }
  console.log("");
});

function tokenFromRequest(req) {
  const authHeader = req.get("authorization") || "";

  if (authHeader.toLowerCase().startsWith("bearer ")) {
    return authHeader.slice(7);
  }

  return req.get("x-panel-token") || req.query.token || "";
}

function resolveInsideRoot(inputPath) {
  const requested = String(inputPath || "").replace(/^[/\\]+/, "");
  const target = path.resolve(ROOT_DIR, requested);
  const relative = path.relative(ROOT_DIR, target);

  if (relative.startsWith("..") || path.isAbsolute(relative)) {
    const error = new Error("Path is outside the panel root");
    error.statusCode = 403;
    throw error;
  }

  return target;
}

function toPanelPath(absolutePath) {
  const relative = path.relative(ROOT_DIR, absolutePath);
  return relative ? relative.split(path.sep).join("/") : "";
}

function preferredShell() {
  if (process.platform === "win32") {
    return process.env.ComSpec || "powershell.exe";
  }

  if (process.env.SHELL) {
    return process.env.SHELL;
  }

  return fs.existsSync("/bin/bash") ? "/bin/bash" : "/bin/sh";
}

function shellArgs(shell) {
  if (process.platform === "win32") {
    return shell.toLowerCase().includes("powershell") ? ["-NoLogo"] : [];
  }

  return shell.endsWith("bash") ? ["-l"] : [];
}

function clampNumber(value, min, max, fallback) {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    return fallback;
  }

  return Math.min(max, Math.max(min, Math.floor(number)));
}

async function safeLstat(filePath) {
  try {
    return await fsp.lstat(filePath);
  } catch (error) {
    return null;
  }
}

function safeUserInfo() {
  try {
    return os.userInfo();
  } catch (error) {
    return {};
  }
}

function bytesToHuman(bytes) {
  const units = ["B", "KB", "MB", "GB", "TB"];
  let value = Number(bytes);
  let unit = 0;

  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }

  return `${value.toFixed(value >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function secondsToHuman(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  return [
    days ? `${days}d` : "",
    hours ? `${hours}h` : "",
    `${minutes}m`,
  ]
    .filter(Boolean)
    .join(" ");
}
