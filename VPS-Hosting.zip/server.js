const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const pty = require("node-pty");
const path = require("path");
const fs = require("fs");
const fsp = require("fs/promises");
const os = require("os");
const { spawn } = require("child_process");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const minecraftIo = io.of("/minecraft");

const PORT = Number(process.env.PORT || 3000);
const PANEL_TOKEN = process.env.PANEL_TOKEN || "";
const ROOT_DIR = path.resolve(
  process.env.PANEL_ROOT || process.env.GITHUB_WORKSPACE || process.cwd()
);
const MAX_PREVIEW_BYTES = Number(process.env.MAX_PREVIEW_BYTES || 512 * 1024);
const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_BYTES || 50 * 1024 * 1024);
const SERVERS_DIR = path.join(ROOT_DIR, "servers");
const BACKUPS_DIR = path.join(ROOT_DIR, "backups");
const MAX_PLUGIN_BYTES = Number(process.env.MAX_PLUGIN_BYTES || 150 * 1024 * 1024);

const minecraftProcesses = new Map();
const minecraftHistory = new Map();

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json({ limit: "5mb" }));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use("/api", (req, res, next) => {
  if (!PANEL_TOKEN || tokenFromRequest(req) === PANEL_TOKEN) {
    return next();
  }

  return res.status(401).json({ error: "Invalid panel token" });
});

app.get("/api/system", (req, res) => {
  const cpus = os.cpus();
  const user = safeUserInfo();

  res.json({
    hostname: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    arch: os.arch(),
    shell: preferredShell(),
    root: ROOT_DIR,
    user: user.username || "codespace",
    cpu: cpus[0] ? cpus[0].model : "Unknown CPU",
    cores: cpus.length,
    load: os.loadavg().map((value) => Number(value.toFixed(2))),
    memory: {
      total: bytesToHuman(os.totalmem()),
      free: bytesToHuman(os.freemem()),
    },
    uptime: secondsToHuman(os.uptime()),
  });
});

app.get("/api/files", async (req, res) => {
  try {
    const directory = resolveInsideRoot(req.query.path || "");
    const stat = await fsp.stat(directory);

    if (!stat.isDirectory()) {
      return res.status(400).json({ error: "Path is not a directory" });
    }

    const entries = await fsp.readdir(directory, { withFileTypes: true });
    const files = await Promise.all(
      entries.map(async (entry) => {
        const absolutePath = path.join(directory, entry.name);
        const itemStat = await safeLstat(absolutePath);
        const type = entry.isDirectory()
          ? "folder"
          : entry.isSymbolicLink()
            ? "link"
            : "file";

        return {
          name: entry.name,
          type,
          path: toPanelPath(absolutePath),
          size: itemStat ? itemStat.size : 0,
          modified: itemStat ? itemStat.mtime.toISOString() : null,
        };
      })
    );

    files.sort((a, b) => {
      if (a.type !== b.type) {
        return a.type === "folder" ? -1 : 1;
      }

      return a.name.localeCompare(b.name);
    });

    const currentPath = toPanelPath(directory);
    const parentPath = currentPath ? toPanelPath(path.dirname(directory)) : null;

    res.json({
      root: ROOT_DIR,
      path: currentPath,
      parent: parentPath,
      files,
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.get("/api/file", async (req, res) => {
  try {
    const filePath = resolveInsideRoot(req.query.path || "");
    const stat = await fsp.stat(filePath);

    if (!stat.isFile()) {
      return res.status(400).json({ error: "Path is not a file" });
    }

    if (stat.size > MAX_PREVIEW_BYTES) {
      return res.status(413).json({
        error: `File is bigger than ${bytesToHuman(MAX_PREVIEW_BYTES)}`,
      });
    }

    const buffer = await fsp.readFile(filePath);

    if (buffer.includes(0)) {
      return res.status(415).json({ error: "Binary file preview is blocked" });
    }

    res.json({
      name: path.basename(filePath),
      path: toPanelPath(filePath),
      size: stat.size,
      modified: stat.mtime.toISOString(),
      content: buffer.toString("utf8"),
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.put("/api/file", async (req, res) => {
  try {
    const filePath = resolveInsideRoot(req.body && req.body.path);
    const content = String((req.body && req.body.content) ?? "");
    const directory = path.dirname(filePath);

    await fsp.mkdir(directory, { recursive: true });
    await fsp.writeFile(filePath, content, "utf8");

    const stat = await fsp.stat(filePath);
    res.json({
      ok: true,
      file: {
        name: path.basename(filePath),
        path: toPanelPath(filePath),
        size: stat.size,
        modified: stat.mtime.toISOString(),
      },
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.delete("/api/file", async (req, res) => {
  try {
    const target = resolveInsideRoot(req.query.path || (req.body && req.body.path));

    if (target === ROOT_DIR) {
      return res.status(400).json({ error: "Root folder cannot be deleted" });
    }

    await fsp.rm(target, { recursive: true, force: true });
    res.json({ ok: true });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post("/api/file/new", async (req, res) => {
  try {
    const directory = resolveInsideRoot(req.body && req.body.path);
    const name = sanitizeEntryName(req.body && req.body.name);
    const type = req.body && req.body.type === "folder" ? "folder" : "file";
    const target = assertInsideRoot(path.join(directory, name));

    if (await pathExists(target)) {
      return res.status(409).json({ error: "File or folder already exists" });
    }

    if (type === "folder") {
      await fsp.mkdir(target, { recursive: true });
    } else {
      await fsp.writeFile(target, "", { encoding: "utf8", flag: "wx" });
    }

    res.status(201).json({
      ok: true,
      item: {
        name,
        type,
        path: toPanelPath(target),
      },
    });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post(
  "/api/file/upload",
  express.raw({ type: "*/*", limit: MAX_UPLOAD_BYTES }),
  async (req, res) => {
    try {
      const directory = resolveInsideRoot(req.query.path || "");
      const stat = await fsp.stat(directory);

      if (!stat.isDirectory()) {
        return res.status(400).json({ error: "Upload path is not a directory" });
      }

      const name = sanitizeEntryName(req.get("x-file-name"));

      if (!Buffer.isBuffer(req.body)) {
        return res.status(400).json({ error: "Upload body is empty" });
      }

      const target = assertInsideRoot(path.join(directory, name));
      await fsp.writeFile(target, req.body);

      const itemStat = await fsp.stat(target);
      res.status(201).json({
        ok: true,
        file: {
          name,
          type: "file",
          path: toPanelPath(target),
          size: itemStat.size,
          modified: itemStat.mtime.toISOString(),
        },
      });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message });
    }
  }
);

app.get("/api/minecraft/options", async (req, res) => {
  try {
    const [paper, vanilla] = await Promise.allSettled([
      resolvePaperJar(),
      resolveVanillaJar(),
    ]);

    res.json({
      paper:
        paper.status === "fulfilled"
          ? { version: paper.value.version, build: paper.value.build }
          : null,
      vanilla:
        vanilla.status === "fulfilled"
          ? { version: vanilla.value.version }
          : null,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/minecraft/servers", async (req, res) => {
  try {
    res.json({ servers: await listMinecraftServers() });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post("/api/minecraft/servers", async (req, res) => {
  try {
    const server = await createMinecraftServer(req.body || {});
    res.status(201).json({ server });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.get("/api/minecraft/servers/:id", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    res.json({ server: await hydrateServer(metadata) });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post("/api/minecraft/servers/:id/eula", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    const accepted = Boolean(req.body && req.body.accepted);
    metadata.eulaAccepted = accepted;
    metadata.updatedAt = new Date().toISOString();

    await fsp.writeFile(
      path.join(serverDir(metadata.id), "eula.txt"),
      `eula=${accepted}\n`,
      "utf8"
    );
    await writeServerMetadata(metadata);
    res.json({ server: await hydrateServer(metadata) });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post("/api/minecraft/servers/:id/start", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    const result = await startMinecraftServer(metadata);
    res.json({ server: result });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post("/api/minecraft/servers/:id/stop", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    await stopMinecraftServer(metadata.id);
    res.json({ server: await hydrateServer(metadata) });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post("/api/minecraft/servers/:id/command", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    const command = sanitizeConsoleCommand(req.body && req.body.command);
    const entry = minecraftProcesses.get(metadata.id);

    if (!entry) {
      return res.status(409).json({ error: "Server is not running" });
    }

    entry.process.stdin.write(`${command}\n`);
    appendMinecraftLog(metadata.id, `> ${command}\n`);
    res.json({ ok: true });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.get("/api/minecraft/servers/:id/plugins", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    res.json({ plugins: await listPlugins(metadata.id) });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post(
  "/api/minecraft/servers/:id/plugins",
  express.raw({ type: "*/*", limit: MAX_PLUGIN_BYTES }),
  async (req, res) => {
    try {
      const metadata = await readServerMetadata(req.params.id);
      const fileName = sanitizeJarFileName(req.get("x-file-name"));

      if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
        return res.status(400).json({ error: "Plugin file is empty" });
      }

      const pluginsDir = path.join(serverDir(metadata.id), "plugins");
      await fsp.mkdir(pluginsDir, { recursive: true });
      await fsp.writeFile(path.join(pluginsDir, fileName), req.body);
      res.status(201).json({ plugins: await listPlugins(metadata.id) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message });
    }
  }
);

app.delete("/api/minecraft/servers/:id/plugins/:name", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    const fileName = sanitizeJarFileName(req.params.name);
    const target = path.join(serverDir(metadata.id), "plugins", fileName);
    await fsp.rm(target, { force: true });
    res.json({ plugins: await listPlugins(metadata.id) });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.get("/api/minecraft/servers/:id/backups", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    res.json({ backups: await listBackups(metadata.id) });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

app.post("/api/minecraft/servers/:id/backup", async (req, res) => {
  try {
    const metadata = await readServerMetadata(req.params.id);
    const backup = await createBackup(metadata);
    res.status(201).json({ backup, backups: await listBackups(metadata.id) });
  } catch (error) {
    res.status(error.statusCode || 500).json({ error: error.message });
  }
});

io.use((socket, next) => {
  if (!PANEL_TOKEN || socket.handshake.auth.token === PANEL_TOKEN) {
    return next();
  }

  return next(new Error("Invalid panel token"));
});

io.on("connection", (socket) => {
  const cols = clampNumber(socket.handshake.query.cols, 40, 240, 120);
  const rows = clampNumber(socket.handshake.query.rows, 12, 80, 32);
  const shell = preferredShell();
  const args = shellArgs(shell);

  const terminal = pty.spawn(shell, args, {
    name: "xterm-256color",
    cols,
    rows,
    cwd: ROOT_DIR,
    env: {
      ...process.env,
      TERM: "xterm-256color",
      COLORTERM: "truecolor",
    },
  });

  socket.emit("output", `\r\nConnected to ${os.hostname()} | ${ROOT_DIR}\r\n`);

  terminal.onData((data) => {
    socket.emit("output", data);
  });

  terminal.onExit(({ exitCode }) => {
    socket.emit("output", `\r\nShell exited with code ${exitCode}\r\n`);
    socket.emit("exit", { exitCode });
  });

  socket.on("input", (data) => {
    terminal.write(data);
  });

  socket.on("resize", ({ cols: nextCols, rows: nextRows }) => {
    try {
      terminal.resize(
        clampNumber(nextCols, 40, 240, 120),
        clampNumber(nextRows, 12, 80, 32)
      );
    } catch (error) {
      socket.emit("output", `\r\nResize failed: ${error.message}\r\n`);
    }
  });

  socket.on("disconnect", () => {
    try {
      terminal.kill();
    } catch (error) {
      // Terminal may already be gone.
    }
  });
});

minecraftIo.use((socket, next) => {
  if (!PANEL_TOKEN || socket.handshake.auth.token === PANEL_TOKEN) {
    return next();
  }

  return next(new Error("Invalid panel token"));
});

minecraftIo.on("connection", async (socket) => {
  const serverId = normalizeServerId(socket.handshake.query.serverId);

  if (!serverId) {
    socket.emit("console", "Missing server id\n");
    socket.disconnect();
    return;
  }

  try {
    await readServerMetadata(serverId);
  } catch (error) {
    socket.emit("console", `${error.message}\n`);
    socket.disconnect();
    return;
  }

  socket.join(serverId);
  socket.emit("console-history", minecraftHistory.get(serverId) || []);
  socket.emit("status", { running: minecraftProcesses.has(serverId) });
});

ensureRuntimeFolders().then(() => {
  server.listen(PORT, () => {
    console.log("");
    console.log("Ubuntu VPS Panel is running");
    console.log(`Local: http://localhost:${PORT}`);
    console.log(`Root:  ${ROOT_DIR}`);
    if (PANEL_TOKEN) {
      console.log("Auth:  PANEL_TOKEN is enabled");
    } else {
      console.log("Auth:  no PANEL_TOKEN set");
    }
    console.log("");
  });
});

async function createMinecraftServer(input) {
  await ensureRuntimeFolders();

  const name = String(input.name || "").trim();
  const id = slugifyName(name);
  const type = input.type === "vanilla" ? "vanilla" : "paper";
  const ramGb = clampNumber(input.ramGb, 2, 5, 2);
  const port = clampNumber(input.port, 1, 65535, 25565);
  const connectIp = String(input.ip || "localhost").trim() || "localhost";
  const directory = serverDir(id);
  const backupDirectory = path.join(BACKUPS_DIR, id);

  if (await pathExists(directory)) {
    const error = new Error("Server name already exists");
    error.statusCode = 409;
    throw error;
  }

  await fsp.mkdir(directory, { recursive: true });
  await fsp.mkdir(path.join(directory, "plugins"), { recursive: true });
  await fsp.mkdir(backupDirectory, { recursive: true });

  const metadata = {
    id,
    name,
    type,
    version: "pending",
    build: null,
    connectIp,
    port,
    ramGb,
    jar: "server.jar",
    jarDownloaded: false,
    eulaAccepted: false,
    path: toPanelPath(directory),
    backupPath: toPanelPath(backupDirectory),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    warning: "",
  };

  await writeServerProperties(directory, metadata);
  await fsp.writeFile(path.join(directory, "eula.txt"), "eula=false\n", "utf8");
  await writeStartScripts(directory, metadata);

  if (input.downloadJar !== false) {
    try {
      const jarInfo = type === "vanilla" ? await resolveVanillaJar() : await resolvePaperJar();
      await downloadFile(jarInfo.url, path.join(directory, metadata.jar));
      metadata.version = jarInfo.version;
      metadata.build = jarInfo.build || null;
      metadata.jarDownloaded = true;
    } catch (error) {
      metadata.warning = `Jar download failed: ${error.message}`;
      await fsp.writeFile(
        path.join(directory, "DOWNLOAD_JAR.txt"),
        [
          "Server folder was created, but server.jar was not downloaded.",
          "Run Create Server again with internet access, or place a compatible server.jar here.",
          `Error: ${error.message}`,
          "",
        ].join("\n"),
        "utf8"
      );
    }
  }

  metadata.updatedAt = new Date().toISOString();
  await writeServerMetadata(metadata);
  appendMinecraftLog(id, `${metadata.name} created (${metadata.type})\n`);

  return hydrateServer(metadata);
}

async function startMinecraftServer(metadata) {
  if (minecraftProcesses.has(metadata.id)) {
    return hydrateServer(metadata);
  }

  if (!metadata.eulaAccepted) {
    const error = new Error("Accept Minecraft EULA before starting this server");
    error.statusCode = 409;
    throw error;
  }

  const directory = serverDir(metadata.id);
  const jarPath = path.join(directory, metadata.jar || "server.jar");

  if (!(await pathExists(jarPath))) {
    const error = new Error("server.jar is missing");
    error.statusCode = 409;
    throw error;
  }

  const java = process.env.JAVA_BIN || "java";
  const args = [
    "-Xms1G",
    `-Xmx${clampNumber(metadata.ramGb, 2, 5, 2)}G`,
    "-jar",
    metadata.jar || "server.jar",
    "nogui",
  ];
  const child = spawn(java, args, {
    cwd: directory,
    stdio: ["pipe", "pipe", "pipe"],
    shell: false,
  });

  minecraftProcesses.set(metadata.id, {
    process: child,
    startedAt: new Date().toISOString(),
  });

  appendMinecraftLog(metadata.id, `Starting ${metadata.name}...\n`);

  child.stdout.on("data", (chunk) => appendMinecraftLog(metadata.id, chunk.toString()));
  child.stderr.on("data", (chunk) => appendMinecraftLog(metadata.id, chunk.toString()));
  child.on("error", (error) => {
    minecraftProcesses.delete(metadata.id);
    appendMinecraftLog(metadata.id, `Start failed: ${error.message}\n`);
    minecraftIo.to(metadata.id).emit("status", { running: false });
  });
  child.on("exit", (code) => {
    minecraftProcesses.delete(metadata.id);
    appendMinecraftLog(metadata.id, `Server stopped with code ${code}\n`);
    minecraftIo.to(metadata.id).emit("status", { running: false });
  });

  minecraftIo.to(metadata.id).emit("status", { running: true });
  return hydrateServer(metadata);
}

async function stopMinecraftServer(id) {
  const entry = minecraftProcesses.get(id);

  if (!entry) {
    return;
  }

  appendMinecraftLog(id, "Stopping server...\n");
  entry.process.stdin.write("stop\n");

  setTimeout(() => {
    if (minecraftProcesses.has(id)) {
      try {
        entry.process.kill();
      } catch (error) {
        appendMinecraftLog(id, `Force stop failed: ${error.message}\n`);
      }
    }
  }, 12000);
}

async function createBackup(metadata) {
  const source = serverDir(metadata.id);
  const targetRoot = path.join(BACKUPS_DIR, metadata.id);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const target = path.join(targetRoot, stamp);

  await fsp.mkdir(targetRoot, { recursive: true });
  await fsp.cp(source, target, {
    recursive: true,
    filter: (item) => {
      const name = path.basename(item);
      return !["server.jar", "libraries", "versions", "cache"].includes(name);
    },
  });
  await fsp.writeFile(
    path.join(target, "backup-info.json"),
    `${JSON.stringify({ server: metadata.name, createdAt: new Date().toISOString() }, null, 2)}\n`,
    "utf8"
  );

  appendMinecraftLog(metadata.id, `Backup created: ${stamp}\n`);
  return backupSummary(target);
}

async function listMinecraftServers() {
  await ensureRuntimeFolders();
  const entries = await fsp.readdir(SERVERS_DIR, { withFileTypes: true });
  const servers = [];

  for (const entry of entries) {
    if (!entry.isDirectory()) {
      continue;
    }

    try {
      const metadata = await readServerMetadata(entry.name);
      servers.push(await hydrateServer(metadata));
    } catch (error) {
      // Ignore folders that are not panel-managed servers.
    }
  }

  return servers.sort((a, b) => a.name.localeCompare(b.name));
}

async function hydrateServer(metadata) {
  const directory = serverDir(metadata.id);
  const jarPath = path.join(directory, metadata.jar || "server.jar");
  const runningEntry = minecraftProcesses.get(metadata.id);

  return {
    ...metadata,
    running: Boolean(runningEntry),
    startedAt: runningEntry ? runningEntry.startedAt : null,
    jarDownloaded: await pathExists(jarPath),
    folder: toPanelPath(directory),
    plugins: await listPlugins(metadata.id).catch(() => []),
    backups: await listBackups(metadata.id).catch(() => []),
  };
}

async function listPlugins(id) {
  const pluginsDir = path.join(serverDir(id), "plugins");
  await fsp.mkdir(pluginsDir, { recursive: true });
  const entries = await fsp.readdir(pluginsDir, { withFileTypes: true });
  const plugins = [];

  for (const entry of entries) {
    if (!entry.isFile() || !entry.name.toLowerCase().endsWith(".jar")) {
      continue;
    }

    const stat = await fsp.stat(path.join(pluginsDir, entry.name));
    plugins.push({
      name: entry.name,
      size: stat.size,
      modified: stat.mtime.toISOString(),
    });
  }

  return plugins.sort((a, b) => a.name.localeCompare(b.name));
}

async function listBackups(id) {
  const root = path.join(BACKUPS_DIR, normalizeServerId(id));
  await fsp.mkdir(root, { recursive: true });
  const entries = await fsp.readdir(root, { withFileTypes: true });
  const backups = [];

  for (const entry of entries) {
    if (!entry.isDirectory()) {
      continue;
    }

    backups.push(await backupSummary(path.join(root, entry.name)));
  }

  return backups.sort((a, b) => b.name.localeCompare(a.name));
}

async function backupSummary(backupPath) {
  const stat = await fsp.stat(backupPath);
  return {
    name: path.basename(backupPath),
    path: toPanelPath(backupPath),
    modified: stat.mtime.toISOString(),
  };
}

async function resolvePaperJar() {
  const project = await fetchJson("https://api.papermc.io/v2/projects/paper");
  const version = project.versions[project.versions.length - 1];
  const buildsData = await fetchJson(
    `https://api.papermc.io/v2/projects/paper/versions/${version}/builds`
  );
  const build = buildsData.builds[buildsData.builds.length - 1];
  const fileName = build.downloads.application.name;

  return {
    type: "paper",
    version,
    build: build.build,
    url: `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/${build.build}/downloads/${fileName}`,
  };
}

async function resolveVanillaJar() {
  const manifest = await fetchJson(
    "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
  );
  const version = manifest.latest.release;
  const versionInfo = manifest.versions.find((item) => item.id === version);

  if (!versionInfo) {
    throw new Error("Latest Vanilla version was not found");
  }

  const detail = await fetchJson(versionInfo.url);

  return {
    type: "vanilla",
    version,
    build: null,
    url: detail.downloads.server.url,
  };
}

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: { "user-agent": "ubuntu-vps-panel" },
  });

  if (!response.ok) {
    throw new Error(`${url} returned ${response.status}`);
  }

  return response.json();
}

async function downloadFile(url, targetPath) {
  const response = await fetch(url, {
    headers: { "user-agent": "ubuntu-vps-panel" },
  });

  if (!response.ok) {
    throw new Error(`Download returned ${response.status}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  await fsp.writeFile(targetPath, Buffer.from(arrayBuffer));
}

async function writeServerProperties(directory, metadata) {
  const content = [
    "# Generated by Ubuntu VPS Panel",
    `server-port=${metadata.port}`,
    "server-ip=",
    "motd=Ubuntu VPS Panel Minecraft Server",
    "online-mode=true",
    "enable-command-block=false",
    "spawn-protection=16",
    "view-distance=10",
    "simulation-distance=10",
    "",
  ].join("\n");

  await fsp.writeFile(path.join(directory, "server.properties"), content, "utf8");
}

async function writeStartScripts(directory, metadata) {
  const ram = clampNumber(metadata.ramGb, 2, 5, 2);

  await fsp.writeFile(
    path.join(directory, "start.sh"),
    `#!/usr/bin/env bash\njava -Xms1G -Xmx${ram}G -jar server.jar nogui\n`,
    "utf8"
  );
  await fsp.writeFile(
    path.join(directory, "start.bat"),
    `@echo off\r\njava -Xms1G -Xmx${ram}G -jar server.jar nogui\r\npause\r\n`,
    "utf8"
  );

  if (process.platform !== "win32") {
    await fsp.chmod(path.join(directory, "start.sh"), 0o755);
  }
}

async function readServerMetadata(id) {
  const serverId = normalizeServerId(id);

  if (!serverId) {
    const error = new Error("Invalid server id");
    error.statusCode = 400;
    throw error;
  }

  const file = path.join(serverDir(serverId), ".panel-server.json");

  try {
    return JSON.parse(await fsp.readFile(file, "utf8"));
  } catch (error) {
    const nextError = new Error("Minecraft server was not found");
    nextError.statusCode = 404;
    throw nextError;
  }
}

async function writeServerMetadata(metadata) {
  await fsp.writeFile(
    path.join(serverDir(metadata.id), ".panel-server.json"),
    `${JSON.stringify(metadata, null, 2)}\n`,
    "utf8"
  );
}

function appendMinecraftLog(id, data) {
  const serverId = normalizeServerId(id);
  const history = minecraftHistory.get(serverId) || [];
  history.push(String(data));

  while (history.length > 600) {
    history.shift();
  }

  minecraftHistory.set(serverId, history);
  minecraftIo.to(serverId).emit("console", String(data));
}

async function ensureRuntimeFolders() {
  await fsp.mkdir(SERVERS_DIR, { recursive: true });
  await fsp.mkdir(BACKUPS_DIR, { recursive: true });
}

function tokenFromRequest(req) {
  const authHeader = req.get("authorization") || "";

  if (authHeader.toLowerCase().startsWith("bearer ")) {
    return authHeader.slice(7);
  }

  return req.get("x-panel-token") || req.query.token || "";
}

function resolveInsideRoot(inputPath) {
  const requested = String(inputPath || "").replace(/^[/\\]+/, "");
  const target = path.resolve(ROOT_DIR, requested);

  return assertInsideRoot(target);
}

function assertInsideRoot(targetPath) {
  const target = path.resolve(targetPath);
  const relative = path.relative(ROOT_DIR, target);

  if (relative.startsWith("..") || path.isAbsolute(relative)) {
    const error = new Error("Path is outside the panel root");
    error.statusCode = 403;
    throw error;
  }

  return target;
}

function serverDir(id) {
  const serverId = normalizeServerId(id);
  const target = path.join(SERVERS_DIR, serverId);
  const relative = path.relative(SERVERS_DIR, target);

  if (!serverId || relative.startsWith("..") || path.isAbsolute(relative)) {
    const error = new Error("Invalid server id");
    error.statusCode = 400;
    throw error;
  }

  return target;
}

function toPanelPath(absolutePath) {
  const relative = path.relative(ROOT_DIR, absolutePath);
  return relative ? relative.split(path.sep).join("/") : "";
}

function preferredShell() {
  if (process.platform === "win32") {
    return process.env.ComSpec || "powershell.exe";
  }

  if (process.env.SHELL) {
    return process.env.SHELL;
  }

  return fs.existsSync("/bin/bash") ? "/bin/bash" : "/bin/sh";
}

function shellArgs(shell) {
  if (process.platform === "win32") {
    return shell.toLowerCase().includes("powershell") ? ["-NoLogo"] : [];
  }

  return shell.endsWith("bash") ? ["-l"] : [];
}

function clampNumber(value, min, max, fallback) {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    return fallback;
  }

  return Math.min(max, Math.max(min, Math.floor(number)));
}

function slugifyName(name) {
  const slug = String(name || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48);

  if (!slug) {
    const error = new Error("Server name is required");
    error.statusCode = 400;
    throw error;
  }

  return slug;
}

function normalizeServerId(id) {
  return String(id || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, "");
}

function sanitizeConsoleCommand(command) {
  const value = String(command || "").replace(/[\r\n]/g, "").trim();

  if (!value) {
    const error = new Error("Command is required");
    error.statusCode = 400;
    throw error;
  }

  return value;
}

function sanitizeJarFileName(name) {
  const value = path.basename(String(name || "")).replace(/[^a-zA-Z0-9._-]/g, "");

  if (!value || !value.toLowerCase().endsWith(".jar")) {
    const error = new Error("Only .jar plugin files are allowed");
    error.statusCode = 400;
    throw error;
  }

  return value;
}

function sanitizeEntryName(name) {
  const value = path.basename(String(name || "").trim()).replace(/[<>:"/\\|?*\x00-\x1f]/g, "");

  if (!value || value === "." || value === "..") {
    const error = new Error("Valid file or folder name is required");
    error.statusCode = 400;
    throw error;
  }

  return value;
}

async function safeLstat(filePath) {
  try {
    return await fsp.lstat(filePath);
  } catch (error) {
    return null;
  }
}

async function pathExists(filePath) {
  try {
    await fsp.access(filePath);
    return true;
  } catch (error) {
    return false;
  }
}

function safeUserInfo() {
  try {
    return os.userInfo();
  } catch (error) {
    return {};
  }
}

function bytesToHuman(bytes) {
  const units = ["B", "KB", "MB", "GB", "TB"];
  let value = Number(bytes);
  let unit = 0;

  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }

  return `${value.toFixed(value >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

function secondsToHuman(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  return [
    days ? `${days}d` : "",
    hours ? `${hours}h` : "",
    `${minutes}m`,
  ]
    .filter(Boolean)
    .join(" ");
}
